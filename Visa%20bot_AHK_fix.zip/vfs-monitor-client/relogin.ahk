#Requires AutoHotkey v2.0
#SingleInstance Force

; Повторный вход в VFS через уже открытый обычный Chrome.
; Пароль/логин здесь НЕ хранятся: Chrome подставляет сохранённые данные сам.
; Координаты ниже рассчитаны на экран 1920x1080 по предоставленному скриншоту.

CoordMode "Mouse", "Screen"
SetTitleMatchMode 2

if !WinExist("ahk_exe chrome.exe") {
    ExitApp
}

WinActivate "ahk_exe chrome.exe"
if !WinWaitActive("ahk_exe chrome.exe",, 3) {
    ExitApp
}

Sleep 800

; На странице 401 возвращаемся браузером назад на /login.
Send "!{Left}"

; Ждём загрузку страницы, автозаполнение Chrome и Turnstile.
Sleep 5500

; Кнопка «Войти» на экране 1920x1080.
Click 820, 730

ExitApp
